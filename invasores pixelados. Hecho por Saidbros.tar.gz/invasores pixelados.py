# -*- coding: utf-8
import pilasengine

pilas = pilasengine.iniciar()
cancion_de_fondo = pilas.musica.cargar('Documentos/Popple the Shadow Thief, Popple Battle - Mario & Luigi Superstar Saga Bowsers Minions Music E.mp3')
cancion_de_fondo.reproducir(repetir=True)
puntaje = pilas.actores.Puntaje(-280, 200, color=pilas.colores.negro)

pilas.avisar("Has Tu Mejor Puntuacion")

class AceitunaEnemiga(pilasengine.actores.Aceituna):

    def iniciar(self):
        self.imagen = "Documentos/skin5.png"
        self.aprender( pilas.habilidades.PuedeExplotarConHumo )
        self.x = pilas.azar(-200, 200)
        self.y = 290
        self.velocidad = pilas.azar(10, 130) / 10.0

    def actualizar(self):
        self.rotacion += 5
        self.y -= self.velocidad

        # Elimina el objeto cuando sale de la pantalla.
        if self.y < -300:
            self.eliminar()

fondo = pilas.fondos.Galaxia(dy=-5)

enemigos = pilas.actores.Grupo()

def crear_enemigo():
    actor = AceitunaEnemiga(pilas)
    enemigos.agregar(actor)

pilas.tareas.siempre(0.4, crear_enemigo)
 

nave = pilas.actores.NaveRoja(y=-200)
nave.x=-280
nave.aprender(pilas.habilidades.LimitadoABordesDePantalla)
nave.definir_enemigos(enemigos, puntaje.aumentar)
nave.escala=0.8
pilas.colisiones.agregar(nave, enemigos, nave.eliminar)

nave.velocidad = 7
